package com.avirantenterprises.infocollector.repository.educational;

import com.avirantenterprises.infocollector.model.educational.CertificationUploadForm;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificationUploadFormRepository extends JpaRepository<CertificationUploadForm, Long> {
}
